package com.bharath.dating;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatingapiApplicationTests {

	@Test
	public void contextLoads() {
	}
}
